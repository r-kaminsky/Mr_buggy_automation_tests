//SDA Homework Robert Kamiński 27.08.19

package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import pages.Logged;
import pages.Login;
import pages.ForgotPassword;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class MainTests {

    private WebDriver driver;
    private WebElement element;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }


    @Test
    public void TC_LoginPage_01() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");

        Login login = new Login(driver);
        ForgotPassword forgotPassword = new ForgotPassword(driver);

        login.clickLogo();
        login.clickEmail();
        login.clickHaslo();
        login.clickZaloguj();
        login.clickZapamietajMnie();
        login.clickZapamietajMnie();
        login.clickNiePamietamHasla();
        forgotPassword.clickEmail();
        forgotPassword.clickOdzyskajHaslo();
        forgotPassword.clickCaptcha();
        forgotPassword.clickKokpit();
        login.clickKokpit();
        login.clickSkrzynkaPocztowa();

    }

    @Test
    public void TC_LoginPage_02() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");

        WebElement clickBox1 = driver.findElement(By.xpath("//input[@name='remember']"));
        WebElement clickbox2 = driver.findElement(By.xpath("//input[@name='email']"));
        WebElement clickbox3 = driver.findElement(By.xpath("//input[@name='password']"));

        if (!clickBox1.isSelected()) {
            System.out.println("Remember clickbox is enabled");
        } else {
            System.out.println("Remember clickbox is disabled");

        }
        if (!clickbox2.isSelected()) {
            System.out.println("Email clickbox is enabled");
        } else {
            System.out.println("Email clickbox is disabled");

        }
        if (!clickbox3.isSelected()) {
            System.out.println("Password clickbox is enabled");
        } else {
            System.out.println("Password clickbox is disabled");

        }
    }

    @Test
    public void TC_LoginPage_03() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");
        Login login = new Login(driver);
        Logged logged = new Logged(driver);

        login.insertEmail("admin@tc2014.pl");
        login.insertPassword("12qwAS");
        login.clickZaloguj();
        logged.clickWyloguj();


    }

    @Test
    public void TC_LoginPage_04() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");
        Login login = new Login(driver);
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(1000);

        login.insertEmail("user" + randomInt + "@gmail.com");
        login.insertPassword("12qwAS");
        login.clickZaloguj();

    }

    @Test
    public void TC_LoginPage_06() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");
        Login login = new Login(driver);
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(1000);


        login.insertEmail("admin@tc2014.pl");
        login.insertPassword("Pass" + randomInt);
        login.clickZaloguj();

    }

    @Test
    public void TC_LoginPage_07() {
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");
        Login login = new Login(driver);
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(1000);


        login.insertEmail("user" + randomInt +"@gmail.com");
        login.insertPassword("Pass" + randomInt);
        login.clickZaloguj();

    }

        @Test
        public void TC_LoginPage_08(){
        driver.get("http://demo.mrbuggy2.testarena.pl/zaloguj");
        Login login = new Login(driver);
        Logged logged = new Logged(driver);
        Actions act = new Actions(driver);


        login.insertEmail("admin@tc2014.pl");
        login.insertPassword("12qwAS");
        act.sendKeys(Keys.ENTER).perform();
        logged.clickWyloguj();

        }

        @After
        public void  shutDown() {
           driver.quit();
        }
    }


