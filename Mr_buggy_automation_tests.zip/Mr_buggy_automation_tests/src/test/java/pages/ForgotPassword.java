package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class ForgotPassword {

    private WebDriver driver;
    private CustomWait customWait;

    private By email = By.cssSelector("#email");
    private By odzyskajHaslo = By.cssSelector("#recover");
    private By captcha = By.cssSelector("#recover");
    private By kokpit = By.cssSelector("#footer_static > span:nth-child(1) > a:nth-child(1)");

    public ForgotPassword(WebDriver driver) {
        this.driver = driver;
        customWait = new CustomWait(driver);
    }
    public void clickEmail() {
        WebElement element = driver.findElement(email);
        customWait.clickElementVisible(element);
    }
    public void clickOdzyskajHaslo() {
        WebElement element = driver.findElement(odzyskajHaslo);
        customWait.clickElementVisible(element);
    }
    public void clickCaptcha() {
        WebElement element = driver.findElement(captcha);
        customWait.clickElementVisible(element);
    }
    public void clickKokpit() {
        WebElement element = driver.findElement(kokpit);
        customWait.clickElementVisible(element);
    }
}
