package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Logged {

    private WebDriver driver;
    private CustomWait customWait;

    private By wyloguj = By.cssSelector(".top_right > div:nth-child(4) > a:nth-child(1)");

    public Logged(WebDriver driver) {
        this.driver = driver;
        customWait = new CustomWait(driver);

    }

    public void clickWyloguj() {
        WebElement element = driver.findElement(wyloguj);
        customWait.clickElementVisible(element);
    }



}
