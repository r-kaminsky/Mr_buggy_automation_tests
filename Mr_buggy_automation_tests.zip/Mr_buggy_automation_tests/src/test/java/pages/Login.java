package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {

    private WebDriver driver;
    private CustomWait customWait;

    private By logo = By.cssSelector(".login_tc_header");
    private By email = By.cssSelector("#email");
    private By haslo = By.cssSelector("#password");
    private By zaloguj = By.cssSelector("#login");
    private By zapamietajMnie = By.cssSelector("#remember");
    private By niePamietamHasla = By.cssSelector(".remember_check > a:nth-child(4)");
    private By kokpit = By.cssSelector("#footer_static > span:nth-child(1) > a:nth-child(1)");
    private By skrzynkaPocztowa = By.cssSelector(".j_new_window");


    public Login(WebDriver driver) {
        this.driver = driver;
        customWait = new CustomWait(driver);
    }

    public void clickLogo() {
        WebElement element = driver.findElement(logo);
        customWait.clickElementVisible(element);
    }

    public void clickEmail() {
        WebElement element = driver.findElement(email);
        customWait.clickElementVisible(element);
    }

    public void clickHaslo() {
        WebElement element = driver.findElement(haslo);
        customWait.clickElementVisible(element);
    }

    public void clickZaloguj() {
        WebElement element = driver.findElement(zaloguj);
        customWait.clickElementVisible(element);
    }

    public void clickZapamietajMnie() {
        WebElement element = driver.findElement(zapamietajMnie);
        customWait.clickElementVisible(element);
    }

    public void clickNiePamietamHasla() {
        WebElement element = driver.findElement(niePamietamHasla);
        customWait.clickElementVisible(element);
    }

    public void clickKokpit() {
        WebElement element = driver.findElement(kokpit);
        customWait.clickElementVisible(element);
    }

    public void clickSkrzynkaPocztowa() {
        WebElement element = driver.findElement(skrzynkaPocztowa);
        customWait.clickElementVisible(element);
    }
    public void insertEmail(String value){
        WebElement element = driver.findElement(email);
        element.sendKeys(value);
    }
    public void insertPassword(String value){
        WebElement element = driver.findElement(haslo);
        element.sendKeys(value);
    }





}


