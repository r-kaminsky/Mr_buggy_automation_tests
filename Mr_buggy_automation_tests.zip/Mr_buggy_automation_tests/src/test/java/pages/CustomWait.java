package pages;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CustomWait {

    private static final int DEFAULT_TIMEOUT_IN_SEC = 10;
    private final WebDriver driver;

    public CustomWait(WebDriver driver) {
        this.driver = driver;
    }

    public FluentWait<WebDriver> createFluentWait() {
        return new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SEC);
    }

    private FluentWait<WebDriver> createWait(final int seconds) {
        return createFluentWait().withTimeout(Duration.ofSeconds(seconds));
    }

    public boolean isElementVisible(final WebElement element) {
        FluentWait<WebDriver> wait = createWait(DEFAULT_TIMEOUT_IN_SEC);
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public void clickElementVisible(final WebElement element) {
        isElementVisible(element);
        element.click();
    }

}
